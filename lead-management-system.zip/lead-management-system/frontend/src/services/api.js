// API service - all backend communication goes through here
// In development, Vite proxies /api to http://localhost:5000
// In production, set VITE_API_URL to the deployed backend URL

const API_BASE = import.meta.env.VITE_API_URL || '';

async function request(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = data.errors ? data.errors.join(', ') : data.error || 'Request failed';
    throw new Error(message);
  }
  return data;
}

export const leadsApi = {
  getAll: (filters = {}) => {
    const params = new URLSearchParams();
    if (filters.search) params.append('search', filters.search);
    if (filters.status) params.append('status', filters.status);
    if (filters.source) params.append('source', filters.source);
    const qs = params.toString();
    return request(`/api/leads${qs ? `?${qs}` : ''}`);
  },
  getStats: () => request('/api/leads/stats'),
  create: (lead) =>
    request('/api/leads', { method: 'POST', body: JSON.stringify(lead) }),
  updateStatus: (id, status) =>
    request(`/api/leads/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),
  delete: (id) => request(`/api/leads/${id}`, { method: 'DELETE' }),
};
