// Centralised API client for the backend.
// Uses fetch under the hood and throws meaningful errors so UI components
// can show a single toast on failure.

const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api';

async function request(path, options = {}) {
  const url = `${BASE_URL}${path}`;
  const response = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });

  // 204 No Content (e.g. DELETE)
  if (response.status === 204) return null;

  let data = null;
  const text = await response.text();
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = { error: text };
    }
  }

  if (!response.ok) {
    const message =
      (data && (data.error || data.message)) ||
      `Request failed with status ${response.status}`;
    const details = data && data.details ? ` (${data.details.join(', ')})` : '';
    throw new Error(message + details);
  }

  return data;
}

export const api = {
  listLeads: (params = {}) => {
    const qs = new URLSearchParams(
      Object.entries(params).filter(([, v]) => v !== '' && v != null)
    ).toString();
    return request(`/leads${qs ? `?${qs}` : ''}`);
  },

  getStats: () => request('/leads/stats'),

  createLead: (payload) =>
    request('/leads', { method: 'POST', body: JSON.stringify(payload) }),

  updateLeadStatus: (id, status) =>
    request(`/leads/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),

  deleteLead: (id) => request(`/leads/${id}`, { method: 'DELETE' }),
};
