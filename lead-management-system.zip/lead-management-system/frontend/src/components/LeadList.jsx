const STATUSES = ['Interested', 'Not Interested', 'Converted'];

const statusClass = (status) => {
  if (status === 'Converted') return 'badge badge-green';
  if (status === 'Not Interested') return 'badge badge-red';
  return 'badge badge-blue';
};

const sourceIcon = (source) => {
  if (source === 'Call') return '📞';
  if (source === 'WhatsApp') return '💬';
  if (source === 'Field') return '🚶';
  return '•';
};

const formatDate = (iso) => {
  const d = new Date(iso);
  return d.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
};

export default function LeadList({ leads, loading, onStatusChange, onDelete }) {
  if (loading) {
    return <div className="empty-state">Loading leads…</div>;
  }

  if (leads.length === 0) {
    return (
      <div className="empty-state">
        <p>No leads found.</p>
        <p className="empty-hint">Add your first lead using the form above.</p>
      </div>
    );
  }

  return (
    <div className="table-wrapper">
      <table className="lead-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Phone</th>
            <th>Source</th>
            <th>Status</th>
            <th>Added</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {leads.map((lead) => (
            <tr key={lead.id}>
              <td className="cell-name">{lead.name}</td>
              <td className="cell-phone">
                <a href={`tel:${lead.phone}`}>{lead.phone}</a>
              </td>
              <td>
                <span className="source-tag">
                  {sourceIcon(lead.source)} {lead.source}
                </span>
              </td>
              <td>
                <span className={statusClass(lead.status)}>{lead.status}</span>
              </td>
              <td className="cell-date">{formatDate(lead.created_at)}</td>
              <td className="cell-actions">
                <select
                  value={lead.status}
                  onChange={(e) => onStatusChange(lead.id, e.target.value)}
                  className="status-select"
                  aria-label={`Change status for ${lead.name}`}
                >
                  {STATUSES.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
                <button
                  className="btn btn-danger btn-sm"
                  onClick={() => {
                    if (window.confirm(`Delete lead "${lead.name}"?`)) {
                      onDelete(lead.id);
                    }
                  }}
                  aria-label={`Delete ${lead.name}`}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
