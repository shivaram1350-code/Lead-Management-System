import { useState } from 'react';

const SOURCES = ['Call', 'WhatsApp', 'Field'];

export default function LeadForm({ onSubmit, submitting }) {
  const [form, setForm] = useState({ name: '', phone: '', source: 'Call' });
  const [errors, setErrors] = useState({});

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = 'Name is required';
    else if (form.name.trim().length > 100) e.name = 'Max 100 characters';

    const cleanPhone = form.phone.replace(/[\s-]/g, '');
    if (!form.phone.trim()) e.phone = 'Phone is required';
    else if (!/^\+?\d{10,15}$/.test(cleanPhone))
      e.phone = '10-15 digits (optionally +)';

    if (!SOURCES.includes(form.source)) e.source = 'Select a valid source';
    return e;
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    try {
      await onSubmit({
        name: form.name.trim(),
        phone: form.phone.trim(),
        source: form.source,
      });
      setForm({ name: '', phone: '', source: 'Call' });
      setErrors({});
    } catch (_err) {
      // Parent handles toast, nothing more to do here
    }
  };

  const handleChange = (field) => (event) => {
    setForm({ ...form, [field]: event.target.value });
    if (errors[field]) setErrors({ ...errors, [field]: undefined });
  };

  return (
    <form className="lead-form" onSubmit={handleSubmit} noValidate>
      <h2 className="card-title">Add New Lead</h2>

      <div className="form-grid">
        <div className="form-field">
          <label htmlFor="name">Name</label>
          <input
            id="name"
            type="text"
            value={form.name}
            onChange={handleChange('name')}
            placeholder="e.g. Rahul Sharma"
            className={errors.name ? 'input-error' : ''}
          />
          {errors.name && <span className="error-text">{errors.name}</span>}
        </div>

        <div className="form-field">
          <label htmlFor="phone">Phone</label>
          <input
            id="phone"
            type="tel"
            value={form.phone}
            onChange={handleChange('phone')}
            placeholder="e.g. 9876543210"
            className={errors.phone ? 'input-error' : ''}
          />
          {errors.phone && <span className="error-text">{errors.phone}</span>}
        </div>

        <div className="form-field">
          <label htmlFor="source">Source</label>
          <select
            id="source"
            value={form.source}
            onChange={handleChange('source')}
            className={errors.source ? 'input-error' : ''}
          >
            {SOURCES.map((src) => (
              <option key={src} value={src}>
                {src}
              </option>
            ))}
          </select>
          {errors.source && <span className="error-text">{errors.source}</span>}
        </div>

        <div className="form-field form-submit">
          <button type="submit" className="btn btn-primary" disabled={submitting}>
            {submitting ? 'Adding…' : '+ Add Lead'}
          </button>
        </div>
      </div>
    </form>
  );
}
