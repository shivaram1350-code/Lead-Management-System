export default function Dashboard({ stats }) {
  if (!stats) return null;

  const cards = [
    { label: 'Total Leads', value: stats.total, color: '#4f46e5' },
    { label: 'Interested', value: stats.interested, color: '#0ea5e9' },
    { label: 'Converted', value: stats.converted, color: '#10b981' },
    { label: 'Not Interested', value: stats.not_interested, color: '#ef4444' },
    { label: 'Conversion Rate', value: `${stats.conversion_rate}%`, color: '#f59e0b' },
  ];

  return (
    <div className="dashboard">
      {cards.map((card) => (
        <div className="stat-card" key={card.label} style={{ borderTopColor: card.color }}>
          <div className="stat-label">{card.label}</div>
          <div className="stat-value" style={{ color: card.color }}>
            {card.value}
          </div>
        </div>
      ))}
    </div>
  );
}
