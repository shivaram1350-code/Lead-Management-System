import { useState } from 'react';

const STATUSES = ['New', 'Interested', 'Not Interested', 'Converted'];

function statusClass(status) {
  return `status-pill status-${status.toLowerCase().replace(/\s+/g, '-')}`;
}

function formatDate(iso) {
  const d = new Date(iso);
  return d.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export default function LeadCard({ lead, onStatusChange, onDelete }) {
  const [updating, setUpdating] = useState(false);
  const [deleting, setDeleting] = useState(false);

  async function handleStatus(newStatus) {
    if (newStatus === lead.status) return;
    setUpdating(true);
    try {
      await onStatusChange(lead.id, newStatus);
    } finally {
      setUpdating(false);
    }
  }

  async function handleDelete() {
    if (!window.confirm(`Delete lead "${lead.name}"? This cannot be undone.`))
      return;
    setDeleting(true);
    try {
      await onDelete(lead.id);
    } finally {
      setDeleting(false);
    }
  }

  return (
    <article className="lead-card">
      <div className="lead-header">
        <div>
          <h3 className="lead-name">{lead.name}</h3>
          <div className="lead-meta">
            <span>📞 {lead.phone}</span>
            <span className="source-badge">{lead.source}</span>
          </div>
        </div>
        <span className={statusClass(lead.status)}>{lead.status}</span>
      </div>

      <div className="lead-footer">
        <div className="lead-timestamp">Added {formatDate(lead.created_at)}</div>
        <div className="lead-actions">
          <select
            value={lead.status}
            onChange={(e) => handleStatus(e.target.value)}
            disabled={updating || deleting}
            aria-label={`Change status for ${lead.name}`}
          >
            {STATUSES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
          <button
            type="button"
            className="btn btn-danger"
            onClick={handleDelete}
            disabled={deleting || updating}
          >
            {deleting ? 'Deleting…' : 'Delete'}
          </button>
        </div>
      </div>
    </article>
  );
}
