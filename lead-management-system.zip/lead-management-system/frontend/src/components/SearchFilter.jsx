export default function SearchFilter({ filters, onChange }) {
  const update = (field) => (event) => {
    onChange({ ...filters, [field]: event.target.value });
  };

  const clear = () => onChange({ search: '', status: '', source: '' });

  const hasActiveFilters = filters.search || filters.status || filters.source;

  return (
    <div className="filter-bar">
      <input
        type="text"
        placeholder="Search by name or phone…"
        value={filters.search}
        onChange={update('search')}
        className="filter-input"
      />
      <select value={filters.status} onChange={update('status')} className="filter-select">
        <option value="">All Statuses</option>
        <option value="Interested">Interested</option>
        <option value="Not Interested">Not Interested</option>
        <option value="Converted">Converted</option>
      </select>
      <select value={filters.source} onChange={update('source')} className="filter-select">
        <option value="">All Sources</option>
        <option value="Call">Call</option>
        <option value="WhatsApp">WhatsApp</option>
        <option value="Field">Field</option>
      </select>
      {hasActiveFilters && (
        <button onClick={clear} className="btn btn-ghost">
          Clear
        </button>
      )}
    </div>
  );
}
