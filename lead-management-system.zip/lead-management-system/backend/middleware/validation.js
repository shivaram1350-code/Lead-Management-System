// Input validation for lead-related endpoints.
// Kept dependency-free (no Joi/Zod) to keep the project lean.

const VALID_SOURCES = ['Call', 'WhatsApp', 'Field'];
const VALID_STATUSES = ['New', 'Interested', 'Not Interested', 'Converted'];

// Phone: digits, optional leading +, length 7-15. Spaces/dashes stripped first.
const PHONE_REGEX = /^\+?\d{7,15}$/;

function validateCreateLead(req, res, next) {
  const errors = [];
  let { name, phone, source } = req.body || {};

  // Name
  if (!name || typeof name !== 'string' || !name.trim()) {
    errors.push('Name is required.');
  } else if (name.trim().length < 2 || name.trim().length > 100) {
    errors.push('Name must be between 2 and 100 characters.');
  }

  // Phone
  if (!phone || typeof phone !== 'string' || !phone.trim()) {
    errors.push('Phone is required.');
  } else {
    const cleaned = phone.replace(/[\s-]/g, '');
    if (!PHONE_REGEX.test(cleaned)) {
      errors.push('Phone must be 7-15 digits, optionally prefixed with "+".');
    }
  }

  // Source
  if (!source || !VALID_SOURCES.includes(source)) {
    errors.push(`Source must be one of: ${VALID_SOURCES.join(', ')}.`);
  }

  if (errors.length) {
    return res.status(400).json({ error: 'Validation failed', details: errors });
  }

  // Normalise inputs onto req.body for the controller
  req.body.name = name.trim();
  req.body.phone = phone.replace(/[\s-]/g, '');
  req.body.source = source;
  next();
}

function validateStatusUpdate(req, res, next) {
  const { status } = req.body || {};
  if (!status || !VALID_STATUSES.includes(status)) {
    return res.status(400).json({
      error: 'Validation failed',
      details: [`Status must be one of: ${VALID_STATUSES.join(', ')}.`],
    });
  }
  next();
}

function validateIdParam(req, res, next) {
  const id = parseInt(req.params.id, 10);
  if (!Number.isInteger(id) || id <= 0) {
    return res.status(400).json({ error: 'Invalid lead id.' });
  }
  req.params.id = id;
  next();
}

module.exports = {
  validateCreateLead,
  validateStatusUpdate,
  validateIdParam,
  VALID_SOURCES,
  VALID_STATUSES,
};
