const pool = require('../db/pool');
const asyncHandler = require('../utils/asyncHandler');
const { VALID_SOURCES, VALID_STATUSES } = require('../middleware/validation');

// POST /api/leads
exports.createLead = asyncHandler(async (req, res) => {
  const { name, phone, source } = req.body;
  const { rows } = await pool.query(
    `INSERT INTO leads (name, phone, source)
     VALUES ($1, $2, $3)
     RETURNING *`,
    [name, phone, source]
  );
  res.status(201).json(rows[0]);
});

// GET /api/leads?search=&status=&source=
exports.getLeads = asyncHandler(async (req, res) => {
  const { search, status, source } = req.query;
  const clauses = [];
  const values = [];

  if (search && search.trim()) {
    values.push(`%${search.trim()}%`);
    clauses.push(`(name ILIKE $${values.length} OR phone ILIKE $${values.length})`);
  }
  if (status && VALID_STATUSES.includes(status)) {
    values.push(status);
    clauses.push(`status = $${values.length}`);
  }
  if (source && VALID_SOURCES.includes(source)) {
    values.push(source);
    clauses.push(`source = $${values.length}`);
  }

  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  const { rows } = await pool.query(
    `SELECT * FROM leads ${where} ORDER BY created_at DESC`,
    values
  );
  res.json(rows);
});

// GET /api/leads/stats — dashboard counts
exports.getLeadStats = asyncHandler(async (req, res) => {
  const { rows } = await pool.query(`
    SELECT
      COUNT(*)::int                                                        AS total,
      COUNT(*) FILTER (WHERE status = 'New')::int                          AS new,
      COUNT(*) FILTER (WHERE status = 'Interested')::int                   AS interested,
      COUNT(*) FILTER (WHERE status = 'Not Interested')::int               AS not_interested,
      COUNT(*) FILTER (WHERE status = 'Converted')::int                    AS converted,
      COUNT(*) FILTER (WHERE source = 'Call')::int                         AS source_call,
      COUNT(*) FILTER (WHERE source = 'WhatsApp')::int                     AS source_whatsapp,
      COUNT(*) FILTER (WHERE source = 'Field')::int                        AS source_field
    FROM leads
  `);
  res.json(rows[0]);
});

// PATCH /api/leads/:id/status
exports.updateLeadStatus = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const { rows } = await pool.query(
    `UPDATE leads SET status = $1 WHERE id = $2 RETURNING *`,
    [status, id]
  );
  if (!rows.length) {
    return res.status(404).json({ error: 'Lead not found.' });
  }
  res.json(rows[0]);
});

// DELETE /api/leads/:id
exports.deleteLead = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { rowCount } = await pool.query(`DELETE FROM leads WHERE id = $1`, [id]);
  if (!rowCount) {
    return res.status(404).json({ error: 'Lead not found.' });
  }
  res.status(204).send();
});
