// Programmatically applies db/schema.sql.
// Useful in environments where running psql directly isn't convenient.
const fs = require('fs');
const path = require('path');
const pool = require('./pool');

(async () => {
  try {
    const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
    await pool.query(sql);
    console.log('Database schema initialised successfully.');
    process.exit(0);
  } catch (err) {
    console.error('Failed to initialise database:', err.message);
    process.exit(1);
  }
})();
