// Wraps async route handlers so errors are passed to Express's error middleware
// without needing try/catch in every controller.
module.exports = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};
