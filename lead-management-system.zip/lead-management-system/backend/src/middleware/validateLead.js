// Validation middleware for lead inputs

const VALID_SOURCES = ['Call', 'WhatsApp', 'Field'];
const VALID_STATUSES = ['Interested', 'Not Interested', 'Converted'];

const validateLead = (req, res, next) => {
  const { name, phone, source } = req.body;
  const errors = [];

  // Name validation
  if (!name || typeof name !== 'string' || name.trim().length === 0) {
    errors.push('Name is required');
  } else if (name.trim().length > 100) {
    errors.push('Name must be 100 characters or less');
  }

  // Phone validation — accepts 10-15 digits, optional + prefix
  if (!phone || typeof phone !== 'string') {
    errors.push('Phone is required');
  } else {
    const cleanPhone = phone.replace(/[\s-]/g, '');
    if (!/^\+?\d{10,15}$/.test(cleanPhone)) {
      errors.push('Phone must be 10-15 digits (optionally prefixed with +)');
    }
  }

  // Source validation
  if (!source) {
    errors.push('Source is required');
  } else if (!VALID_SOURCES.includes(source)) {
    errors.push(`Source must be one of: ${VALID_SOURCES.join(', ')}`);
  }

  if (errors.length > 0) {
    return res.status(400).json({ success: false, errors });
  }

  // Normalise data on the request
  req.body.name = name.trim();
  req.body.phone = phone.trim();
  next();
};

const validateStatus = (req, res, next) => {
  const { status } = req.body;
  if (!status || !VALID_STATUSES.includes(status)) {
    return res.status(400).json({
      success: false,
      errors: [`Status must be one of: ${VALID_STATUSES.join(', ')}`],
    });
  }
  next();
};

module.exports = { validateLead, validateStatus, VALID_SOURCES, VALID_STATUSES };
