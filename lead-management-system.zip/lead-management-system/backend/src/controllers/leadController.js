const db = require('../config/db');

// GET /api/leads - Get all leads (with optional search & filter)
exports.getAllLeads = async (req, res) => {
  try {
    const { search, status, source } = req.query;

    let query = 'SELECT * FROM leads WHERE 1=1';
    const params = [];
    let idx = 1;

    if (search) {
      query += ` AND (name ILIKE $${idx} OR phone ILIKE $${idx})`;
      params.push(`%${search}%`);
      idx++;
    }
    if (status) {
      query += ` AND status = $${idx}`;
      params.push(status);
      idx++;
    }
    if (source) {
      query += ` AND source = $${idx}`;
      params.push(source);
      idx++;
    }

    query += ' ORDER BY created_at DESC';

    const result = await db.query(query, params);
    res.json({ success: true, count: result.rows.length, data: result.rows });
  } catch (err) {
    console.error('Error fetching leads:', err);
    res.status(500).json({ success: false, error: 'Failed to fetch leads' });
  }
};

// GET /api/leads/stats - Dashboard statistics
exports.getStats = async (req, res) => {
  try {
    const result = await db.query(`
      SELECT
        COUNT(*) AS total,
        COUNT(*) FILTER (WHERE status = 'Interested') AS interested,
        COUNT(*) FILTER (WHERE status = 'Not Interested') AS not_interested,
        COUNT(*) FILTER (WHERE status = 'Converted') AS converted,
        COUNT(*) FILTER (WHERE source = 'Call') AS source_call,
        COUNT(*) FILTER (WHERE source = 'WhatsApp') AS source_whatsapp,
        COUNT(*) FILTER (WHERE source = 'Field') AS source_field
      FROM leads
    `);

    const row = result.rows[0];
    // Convert string counts to numbers
    const stats = Object.fromEntries(
      Object.entries(row).map(([k, v]) => [k, parseInt(v, 10)])
    );

    // Conversion rate as percentage
    stats.conversion_rate = stats.total > 0
      ? Math.round((stats.converted / stats.total) * 100)
      : 0;

    res.json({ success: true, data: stats });
  } catch (err) {
    console.error('Error fetching stats:', err);
    res.status(500).json({ success: false, error: 'Failed to fetch stats' });
  }
};

// POST /api/leads - Add a new lead
exports.createLead = async (req, res) => {
  try {
    const { name, phone, source } = req.body;
    const result = await db.query(
      `INSERT INTO leads (name, phone, source)
       VALUES ($1, $2, $3) RETURNING *`,
      [name, phone, source]
    );
    res.status(201).json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error('Error creating lead:', err);
    res.status(500).json({ success: false, error: 'Failed to create lead' });
  }
};

// PATCH /api/leads/:id/status - Update lead status
exports.updateLeadStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const result = await db.query(
      `UPDATE leads SET status = $1 WHERE id = $2 RETURNING *`,
      [status, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Lead not found' });
    }
    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error('Error updating lead:', err);
    res.status(500).json({ success: false, error: 'Failed to update lead' });
  }
};

// DELETE /api/leads/:id - Delete a lead
exports.deleteLead = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await db.query(
      `DELETE FROM leads WHERE id = $1 RETURNING id`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Lead not found' });
    }
    res.json({ success: true, message: 'Lead deleted', id: result.rows[0].id });
  } catch (err) {
    console.error('Error deleting lead:', err);
    res.status(500).json({ success: false, error: 'Failed to delete lead' });
  }
};
