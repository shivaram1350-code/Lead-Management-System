const express = require('express');
const router = express.Router();
const leadController = require('../controllers/leadController');
const { validateLead, validateStatus } = require('../middleware/validateLead');

// GET /api/leads - List all leads (supports ?search=, ?status=, ?source=)
router.get('/', leadController.getAllLeads);

// GET /api/leads/stats - Dashboard stats
router.get('/stats', leadController.getStats);

// POST /api/leads - Add a new lead
router.post('/', validateLead, leadController.createLead);

// PATCH /api/leads/:id/status - Update status
router.patch('/:id/status', validateStatus, leadController.updateLeadStatus);

// DELETE /api/leads/:id - Delete a lead
router.delete('/:id', leadController.deleteLead);

module.exports = router;
