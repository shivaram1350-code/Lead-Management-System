const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/leadsController');
const {
  validateCreateLead,
  validateStatusUpdate,
  validateIdParam,
} = require('../middleware/validation');

// Dashboard stats — declared before /:id to avoid conflict
router.get('/stats', ctrl.getLeadStats);

router.get('/', ctrl.getLeads);
router.post('/', validateCreateLead, ctrl.createLead);
router.patch('/:id/status', validateIdParam, validateStatusUpdate, ctrl.updateLeadStatus);
router.delete('/:id', validateIdParam, ctrl.deleteLead);

module.exports = router;
